var class_emb_sys_lib_1_1_hw_1_1_timer___mcu =
[
    [ "ChannelId", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a195a7ddd48d9272f9c533686c72b49bc", [
      [ "CH1", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a195a7ddd48d9272f9c533686c72b49bca703cf81b7a9530ba8650e0ee2f29d68e", null ],
      [ "CH2", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a195a7ddd48d9272f9c533686c72b49bcae574b39c34bd88c27ea641014831e53a", null ],
      [ "CH3", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a195a7ddd48d9272f9c533686c72b49bcaaee6d12bf63ae430250764aa97e9e429", null ],
      [ "CH4", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a195a7ddd48d9272f9c533686c72b49bcaad6a6b3e7230ebcbbb5a26385b11ade7", null ]
    ] ],
    [ "TimerId", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29", [
      [ "TIM_1", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a23f225943735cc6865c9d776ce091fa7", null ],
      [ "TIM_2", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a846add761a01161b530779593f0ba1ed", null ],
      [ "TIM_3", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29ad7cb83c64e3676a2770bd4e46cbd7d05", null ],
      [ "TIM_4", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29aa981ec248215302276e8ec797df830ce", null ],
      [ "TIM_5", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a81eb541cd1edd92229971c6d1ea2ae92", null ],
      [ "TIM_7", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a5a437ffa666e6274f5eb1ec9013b1536", null ],
      [ "TIM_8", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a03eaf9ba205cc6799d047071a6a934fe", null ],
      [ "TIM_9", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a09a42867a5445ca59c37701a16bd3196", null ],
      [ "TIM_10", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a817dbd5ffecd2c6ca7e8b6de069b62f4", null ],
      [ "TIM_11", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29a79c78ffb3f575e12143a0b846ecd3435", null ],
      [ "TIM_12", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29ae4aa0b1e17d844b0e94e49c1360601d3", null ],
      [ "TIM_14", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a7166aae3391813c049d8933425288a29aa54e83887cbeedc64adfac31227a7af1", null ]
    ] ],
    [ "Timer_Mcu", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html#a1c56fd4e59ad88e9a20a0365fc2f25d9", null ]
];