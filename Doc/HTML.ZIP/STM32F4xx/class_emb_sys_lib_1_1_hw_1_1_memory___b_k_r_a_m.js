var class_emb_sys_lib_1_1_hw_1_1_memory___b_k_r_a_m =
[
    [ "Memory_BKRAM", "class_emb_sys_lib_1_1_hw_1_1_memory___b_k_r_a_m.html#a32b6f85ff71e4c595f03a8519863b2a0", null ]
];