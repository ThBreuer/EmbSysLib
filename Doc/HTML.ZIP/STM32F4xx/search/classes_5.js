var searchData=
[
  ['memory_5fbkram_0',['Memory_BKRAM',['../class_emb_sys_lib_1_1_hw_1_1_memory___b_k_r_a_m.html',1,'EmbSysLib::Hw']]],
  ['memory_5fflash_1',['Memory_Flash',['../class_emb_sys_lib_1_1_hw_1_1_memory___flash.html',1,'EmbSysLib::Hw']]]
];
