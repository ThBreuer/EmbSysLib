var class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu =
[
    [ "I2C_ID", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu.html#aec46000c6a1fe2c12c9a0c7ee3677626", [
      [ "I2C_1", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu.html#aec46000c6a1fe2c12c9a0c7ee3677626a0694e914eba7d01884dd5cb4bec24ea8", null ],
      [ "I2C_2", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu.html#aec46000c6a1fe2c12c9a0c7ee3677626ad988f65ed2bdb7911a7d0d6468cac3ac", null ]
    ] ],
    [ "I2Cmaster_Mcu", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu.html#a66d5af64dc9b341223a756b57b2aff58", null ]
];