var class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0 =
[
    [ "SPI_Baudrate", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45", [
      [ "CR_250kHz", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45ac3c0ee155f70081899ebc20ce6e03697", null ],
      [ "CR_500kHz", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45ae7c23dcccfcb7ae865967711bb61eb70", null ],
      [ "CR_1000kHz", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45abd742bf65ea29182038b7a9a250a6639", null ],
      [ "CR_2000kHz", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45a8d201c7f1ef8eed89aace338285ad58d", null ],
      [ "CR_4000kHz", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45a1349159ed26b65772ac7e5c860231cd3", null ],
      [ "CR_8000kHz", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#a85f85a44e20dc2d20cb69815ff7f3e45a92dd91b4a9aea100a744f87cd02f7081", null ]
    ] ],
    [ "SPImaster_0", "class_emb_sys_lib_1_1_hw_1_1_s_p_imaster__0.html#ab81fd07229bdd3f21d940b525aec4fc7", null ]
];