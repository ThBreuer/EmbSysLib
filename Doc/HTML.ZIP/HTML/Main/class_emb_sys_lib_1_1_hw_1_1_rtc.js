var class_emb_sys_lib_1_1_hw_1_1_rtc =
[
    [ "Properties", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html", "class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties" ],
    [ "set", "class_emb_sys_lib_1_1_hw_1_1_rtc.html#ad7232dbebebac407e36eb41d4aa76b92", null ],
    [ "get", "class_emb_sys_lib_1_1_hw_1_1_rtc.html#ac15fdbfd138a5ef779ef20db50475773", null ]
];