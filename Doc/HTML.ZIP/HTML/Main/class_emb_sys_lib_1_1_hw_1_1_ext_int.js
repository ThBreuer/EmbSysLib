var class_emb_sys_lib_1_1_hw_1_1_ext_int =
[
    [ "Task", "class_emb_sys_lib_1_1_hw_1_1_ext_int_1_1_task.html", "class_emb_sys_lib_1_1_hw_1_1_ext_int_1_1_task" ],
    [ "Edge", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#a5be7c8fa582f7b873d1c6caacb633073", [
      [ "NONE", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#a5be7c8fa582f7b873d1c6caacb633073ac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "RISING", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#a5be7c8fa582f7b873d1c6caacb633073ad93abe7aced82e9a4fcac4127a36ece3", null ],
      [ "FALLING", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#a5be7c8fa582f7b873d1c6caacb633073ad24712a6a30c1d431b927d1ba2f84b66", null ],
      [ "BOTH", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#a5be7c8fa582f7b873d1c6caacb633073a627abe5a430420baf29ebe1940a7f2fb", null ]
    ] ],
    [ "add", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#aed154a4363760d2388ee926f9cb52b68", null ],
    [ "enable", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#ad1c349e10e4417179f5eb3cb519670b5", null ],
    [ "disable", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#ac79a817a699d8fb54e52bf6895db1b0d", null ],
    [ "setEdge", "class_emb_sys_lib_1_1_hw_1_1_ext_int.html#ad6080d6b41d27cc16bc5e8d24460f080", null ]
];