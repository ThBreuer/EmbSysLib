var class_emb_sys_lib_1_1_hw_1_1_memory =
[
    [ "unlock", "class_emb_sys_lib_1_1_hw_1_1_memory.html#a6e85429d8705e7c9ee8894a9dcc4de21", null ],
    [ "lock", "class_emb_sys_lib_1_1_hw_1_1_memory.html#a46f222425b3836ac555990f1d8235413", null ],
    [ "getPtr", "class_emb_sys_lib_1_1_hw_1_1_memory.html#ae6b60fbb5690406f22fb3c0202ed03b9", null ],
    [ "write", "class_emb_sys_lib_1_1_hw_1_1_memory.html#a21e5fa775e6981a9d3b9db65f4c69829", null ],
    [ "read", "class_emb_sys_lib_1_1_hw_1_1_memory.html#a880727ca658ec869c450eea136b8ec06", null ],
    [ "erase", "class_emb_sys_lib_1_1_hw_1_1_memory.html#afb61325cd4874b4a3bcbf6a65ee0ab9d", null ],
    [ "getSize", "class_emb_sys_lib_1_1_hw_1_1_memory.html#ab640ecf7808cd7dc9c2f933ef9207516", null ],
    [ "isFlash", "class_emb_sys_lib_1_1_hw_1_1_memory.html#a6eb51a9aaaa89e7b9f9605ef860442b9", null ]
];