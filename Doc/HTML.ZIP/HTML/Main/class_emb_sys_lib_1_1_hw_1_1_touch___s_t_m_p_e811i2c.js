var class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c =
[
    [ "Touch_STMPE811i2c", "class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c.html#a837c799cb50220a896af44000d542a09", null ],
    [ "update", "class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c.html#a7ebd9759b4e3197bf52bab531982c0ff", null ],
    [ "getPosX", "class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c.html#a33d4efc7749b53977addb982fd52af1b", null ],
    [ "getPosY", "class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c.html#a39c533a8c15ef9fb1ba6a5ff34d918f5", null ],
    [ "isTouched", "class_emb_sys_lib_1_1_hw_1_1_touch___s_t_m_p_e811i2c.html#a302a41b4abfdbb00642ec8a8e85145a9", null ]
];