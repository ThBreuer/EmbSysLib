var class_emb_sys_lib_1_1_hw_1_1_net =
[
    [ "Task", "class_emb_sys_lib_1_1_hw_1_1_net_1_1_task.html", "class_emb_sys_lib_1_1_hw_1_1_net_1_1_task" ],
    [ "Net", "class_emb_sys_lib_1_1_hw_1_1_net.html#a257e774ac3ecff1ca9ff823fde0c6f1f", null ],
    [ "update", "class_emb_sys_lib_1_1_hw_1_1_net.html#a96071debec1931881774a970d07aa3f2", null ],
    [ "addTask", "class_emb_sys_lib_1_1_hw_1_1_net.html#aabf9ecb71883534f27f992d14beb6b1c", null ],
    [ "getIP", "class_emb_sys_lib_1_1_hw_1_1_net.html#a6441293867b7712bd0c99db572215c22", null ],
    [ "isNewIP", "class_emb_sys_lib_1_1_hw_1_1_net.html#adccdc96fb302a758a8c91c979b86e76a", null ]
];