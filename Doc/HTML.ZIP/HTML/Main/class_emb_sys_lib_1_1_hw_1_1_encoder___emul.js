var class_emb_sys_lib_1_1_hw_1_1_encoder___emul =
[
    [ "Mode", "class_emb_sys_lib_1_1_hw_1_1_encoder___emul.html#a46c8a310cf4c094f8c80e1cb8dc1f911", [
      [ "NORMAL", "class_emb_sys_lib_1_1_hw_1_1_encoder___emul.html#a46c8a310cf4c094f8c80e1cb8dc1f911a50d1448013c6f17125caee18aa418af7", null ],
      [ "REVERSE", "class_emb_sys_lib_1_1_hw_1_1_encoder___emul.html#a46c8a310cf4c094f8c80e1cb8dc1f911a906b7cc20b42994dda4da492767c1de9", null ]
    ] ],
    [ "update", "class_emb_sys_lib_1_1_hw_1_1_encoder___emul.html#a96071debec1931881774a970d07aa3f2", null ],
    [ "get", "class_emb_sys_lib_1_1_hw_1_1_encoder___emul.html#a537f84a0d155d69644ff7de25b1e5168", null ]
];