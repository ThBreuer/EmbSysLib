var class_emb_sys_lib_1_1_hw_1_1_touch =
[
    [ "update", "class_emb_sys_lib_1_1_hw_1_1_touch.html#ab5a3cb47c0d5985f0a73944936a691fa", null ],
    [ "getPosX", "class_emb_sys_lib_1_1_hw_1_1_touch.html#a33d4efc7749b53977addb982fd52af1b", null ],
    [ "getPosY", "class_emb_sys_lib_1_1_hw_1_1_touch.html#a39c533a8c15ef9fb1ba6a5ff34d918f5", null ],
    [ "isTouched", "class_emb_sys_lib_1_1_hw_1_1_touch.html#a302a41b4abfdbb00642ec8a8e85145a9", null ]
];