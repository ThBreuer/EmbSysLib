var class_emb_sys_lib_1_1_hw_1_1_timer__1 =
[
    [ "Channel", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#a1ce9b523fd4f3b5bbcadcd796183455a", [
      [ "OC1A", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#a1ce9b523fd4f3b5bbcadcd796183455aa41b407acd4885ef4fe4bb1f24e700f88", null ],
      [ "OC1B", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#a1ce9b523fd4f3b5bbcadcd796183455aa89dcdfc1a8eead94cc3d81d18bf8332d", null ],
      [ "OC1C", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#a1ce9b523fd4f3b5bbcadcd796183455aae6c7229257bd35836732cd76f912bc14", null ]
    ] ],
    [ "PWM_MODE", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#ae99d8592e5fac21551d240db82849d09", [
      [ "INTERRUPT", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#ae99d8592e5fac21551d240db82849d09ad5f5c57f205afd4f9df70a8c4e194b45", null ],
      [ "PWM", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#ae99d8592e5fac21551d240db82849d09aef99a276e1f3b62b5df98acc27b38028", null ],
      [ "PWM_INTERRUPT", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#ae99d8592e5fac21551d240db82849d09ad4d976bdfc53ead56c0f3430e1d309b1", null ]
    ] ],
    [ "Timer_1", "class_emb_sys_lib_1_1_hw_1_1_timer__1.html#a76ad8bb11c8b49a458adb65c5c76231f", null ]
];