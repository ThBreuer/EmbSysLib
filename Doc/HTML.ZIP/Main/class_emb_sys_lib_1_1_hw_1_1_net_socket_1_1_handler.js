var class_emb_sys_lib_1_1_hw_1_1_net_socket_1_1_handler =
[
    [ "onReceive", "class_emb_sys_lib_1_1_hw_1_1_net_socket_1_1_handler.html#a81af436ca637ef8272897d58c111bbde", null ],
    [ "onEvent", "class_emb_sys_lib_1_1_hw_1_1_net_socket_1_1_handler.html#a604281ae666b21cb3b9acac228c7ccf2", null ]
];