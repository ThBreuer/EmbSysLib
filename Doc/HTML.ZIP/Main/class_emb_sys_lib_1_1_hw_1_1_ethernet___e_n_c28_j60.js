var class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60 =
[
    [ "LinkState", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#ab0033b911037fd995258d117e65461e0", [
      [ "UNDEFINED", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#ab0033b911037fd995258d117e65461e0a605159e8a4c32319fd69b5d151369d93", null ],
      [ "DISCONNECTED", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#ab0033b911037fd995258d117e65461e0acdaad1112073e3e2ea032424c38c34e1", null ],
      [ "CONNECTED", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#ab0033b911037fd995258d117e65461e0a7a691a2430ec26878897b5fbc9c22a4c", null ]
    ] ],
    [ "Ethernet_ENC28J60", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a7a7abc92e88617db9f215e2495076afd", null ],
    [ "process", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a2e9c5136d19b1a95fc427e0852deab5c", null ],
    [ "setARP", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a784cf1357c632cae16560c73a8b95864", null ],
    [ "setIP", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a753bbd5ac7191d7742c08128ab660f99", null ],
    [ "getIP", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a26ab78694f1bf213445cd860c275eb5f", null ],
    [ "getAddrPhy", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a59183bd04da31b2d79d6aa5f6dae7dd8", null ],
    [ "isNewIP", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a4eba853c58f96f416903ba872b21f700", null ],
    [ "update", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#a96071debec1931881774a970d07aa3f2", null ],
    [ "addTask", "class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#aabf9ecb71883534f27f992d14beb6b1c", null ]
];