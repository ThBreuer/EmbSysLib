/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Embedded-System-Library", "index.html", [
    [ "Todo List", "todo.html", null ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"_analog_8cpp-example.html",
"class_emb_sys_lib_1_1_dev_1_1_digital.html#ae8ca291665d3975a9a7825e7d5eaf601",
"class_emb_sys_lib_1_1_hw_1_1_display_graphic.html#a0efe0f8a9325297dc205d4639bf57b87",
"class_emb_sys_lib_1_1_hw_1_1_display_graphic___o_t_m8009_acmd.html#ae683fe63c33c388e9ba1c6392dd477eb",
"class_emb_sys_lib_1_1_hw_1_1_ethernet___e_n_c28_j60.html#ab0033b911037fd995258d117e65461e0a605159e8a4c32319fd69b5d151369d93",
"class_emb_sys_lib_1_1_hw_1_1_net_eth_t_c_p_1_1_socket.html#ae683fe63c33c388e9ba1c6392dd477eb",
"class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#a4a6fc53e8955a835b6ec3c37a45c0423",
"class_emb_sys_lib_1_1_mod_1_1_isc___uart.html",
"class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html",
"namespace_emb_sys_lib_1_1_std.html#a8bec539b9c6a6e43e9ff787dcaebd835"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';