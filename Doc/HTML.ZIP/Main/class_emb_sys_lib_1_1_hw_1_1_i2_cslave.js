var class_emb_sys_lib_1_1_hw_1_1_i2_cslave =
[
    [ "DataHandler", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave_1_1_data_handler.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave_1_1_data_handler" ]
];