var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwyz~",
  1: "abcdefhimnprstu",
  2: "e",
  3: "abcdefghilmnoprstuw~",
  4: "abcdfghilmnoprstuvwyz",
  5: "n",
  6: "acefklms",
  7: "abcdefilmnoprstu",
  8: "elst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

