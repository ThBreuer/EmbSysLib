var class_emb_sys_lib_1_1_hw_1_1_ethernet =
[
    [ "Header", "class_emb_sys_lib_1_1_hw_1_1_ethernet_1_1_header.html", null ],
    [ "LinkState", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#ab0033b911037fd995258d117e65461e0", [
      [ "UNDEFINED", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#ab0033b911037fd995258d117e65461e0a605159e8a4c32319fd69b5d151369d93", null ],
      [ "DISCONNECTED", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#ab0033b911037fd995258d117e65461e0acdaad1112073e3e2ea032424c38c34e1", null ],
      [ "CONNECTED", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#ab0033b911037fd995258d117e65461e0a7a691a2430ec26878897b5fbc9c22a4c", null ]
    ] ],
    [ "Ethernet", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a7388d45d7ed201ad2889a575e46f012b", null ],
    [ "Init", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a21e74f698f5173851baeba44674488d9", null ],
    [ "process", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a2e9c5136d19b1a95fc427e0852deab5c", null ],
    [ "create", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a0d7738670adb0012285e2cf186ea3ef9", null ],
    [ "PacketSend", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a55ecff086f31a95bcb730e368e887faf", null ],
    [ "PacketReceive", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a4a67eec51e32ae1efeca8e1474ff2ce2", null ],
    [ "getType", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a92dfacbe148abbcfed38e9fbc5cfad98", null ],
    [ "isLinked", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#ad0faef172f6baea7a1d8462f6856c02f", null ],
    [ "setARP", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a784cf1357c632cae16560c73a8b95864", null ],
    [ "setIP", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a753bbd5ac7191d7742c08128ab660f99", null ],
    [ "getIP", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a26ab78694f1bf213445cd860c275eb5f", null ],
    [ "getAddrPhy", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a59183bd04da31b2d79d6aa5f6dae7dd8", null ],
    [ "isNewIP", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a4eba853c58f96f416903ba872b21f700", null ],
    [ "update", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#a96071debec1931881774a970d07aa3f2", null ],
    [ "addTask", "class_emb_sys_lib_1_1_hw_1_1_ethernet.html#aabf9ecb71883534f27f992d14beb6b1c", null ]
];