var class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m =
[
    [ "clear", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#ae683fe63c33c388e9ba1c6392dd477eb", null ],
    [ "refresh", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#afd76a308c9c24c774d5a1f3b5b9ee57b", null ],
    [ "setFont", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a06b2f96e007cfbe655dd215fac1dd017", null ],
    [ "setZoom", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a5fe27a1ddc1b99658221382f4a9e52cf", null ],
    [ "setBackColor", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a026a0427e7c452976e946a48205767b8", null ],
    [ "setPaintColor", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#aaf6de0801a8c103f324387a1b5b41ae1", null ],
    [ "setTextColor", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a700ff55fa714ccc3a0c45c5ddc17fc52", null ],
    [ "gotoPixelPos", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a3a036df17d595fb39249b01fa250d3bd", null ],
    [ "gotoTextPos", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#aff9542f70644efbedffe1c3182131593", null ],
    [ "putChar", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#aaac5dd9e012b5fa09707361d1785a7da", null ],
    [ "putPixel", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#adbba1f6519a74da0dd49321482a95f66", null ],
    [ "putRectangle", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a761d342bef2b9084bd6ad167aa41ae30", null ],
    [ "putBitmap", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#aa7d954397ecbea6146bab46cfd513dc3", null ],
    [ "getWidth", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a04fc184a78a24809989c7b42789866f1", null ],
    [ "getHeight", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a8989587f9cefacb6e87c4804ce4f3998", null ],
    [ "putString", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#ab48ec597ac9a6234433822b695e4898d", null ],
    [ "getNumberOfLines", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#afcebc2be15f272ca91ecb1e9a7224a95", null ],
    [ "getNumberOfColumns", "class_emb_sys_lib_1_1_hw_1_1_display_graphic___g_r_a_m.html#a0efe0f8a9325297dc205d4639bf57b87", null ]
];