var annotated_dup =
[
    [ "EmbSysLib", null, [
      [ "Hw", null, [
        [ "Adc_Mcu", "class_emb_sys_lib_1_1_hw_1_1_adc___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_adc___mcu" ],
        [ "Dac_Mcu", "class_emb_sys_lib_1_1_hw_1_1_dac___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_dac___mcu" ],
        [ "Dsi_Mcu", "class_emb_sys_lib_1_1_hw_1_1_dsi___mcu.html", null ],
        [ "Ethernet_Mcu", "class_emb_sys_lib_1_1_hw_1_1_ethernet___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_ethernet___mcu" ],
        [ "Fmc_Mcu", "class_emb_sys_lib_1_1_hw_1_1_fmc___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_fmc___mcu" ],
        [ "I2Cmaster_Mcu", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_i2_cmaster___mcu" ],
        [ "Ltdc_Mcu", "class_emb_sys_lib_1_1_hw_1_1_ltdc___mcu.html", null ],
        [ "Memory_BKRAM", "class_emb_sys_lib_1_1_hw_1_1_memory___b_k_r_a_m.html", "class_emb_sys_lib_1_1_hw_1_1_memory___b_k_r_a_m" ],
        [ "Memory_Flash", "class_emb_sys_lib_1_1_hw_1_1_memory___flash.html", "class_emb_sys_lib_1_1_hw_1_1_memory___flash" ],
        [ "PinConfig", "class_emb_sys_lib_1_1_hw_1_1_pin_config.html", "class_emb_sys_lib_1_1_hw_1_1_pin_config" ],
        [ "Port_Mcu", "class_emb_sys_lib_1_1_hw_1_1_port___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_port___mcu" ],
        [ "Rtc_Mcu", "class_emb_sys_lib_1_1_hw_1_1_rtc___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_rtc___mcu" ],
        [ "Rtos_Mcu", "class_emb_sys_lib_1_1_hw_1_1_rtos___mcu.html", null ],
        [ "System", "class_emb_sys_lib_1_1_hw_1_1_system.html", "class_emb_sys_lib_1_1_hw_1_1_system" ],
        [ "Timer_Mcu", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_timer___mcu" ],
        [ "Uart_Mcu", "class_emb_sys_lib_1_1_hw_1_1_uart___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_uart___mcu" ],
        [ "USBdevice_Mcu", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice___mcu.html", "class_emb_sys_lib_1_1_hw_1_1_u_s_bdevice___mcu" ]
      ] ]
    ] ]
];