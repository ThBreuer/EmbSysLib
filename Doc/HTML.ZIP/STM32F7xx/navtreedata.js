/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Embedded-System-Library - STM32F7xx", "index.html", [
    [ "Todo List", "todo.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", "functions_eval" ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"_hw_adc_8cpp-example.html",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa0ad59f95082040c89e6274e61f638f85",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa1b198769034058f03e3d1700e6274565",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa2e317787378dc66c61b84d1bdc7efd2e",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa3e105b4bd999a5faa08b3dd4bd458ad6",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa54274fb147fe2d5b28a950f5c81f471b",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa615b77551db4f68082ca330cdfa8c8bd",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa713aabd171a70a7526882cb9478493b0",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa8649abe61c127f650c0706d09b83e745",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aa96bfd9228ccd846036769d872e16209f",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aaa989460b451808e1c28323f439f17938",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aabf708c1872d2ff2d17f2380e1b13f2a2",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aad1bbdfe92e7809a8a36a81d14f545db3",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aae33fa9be1ccbca1350da50b9f7f619e7",
"class_emb_sys_lib_1_1_hw_1_1_pin_config.html#a9e5d7566a457c704d1e373007b4cb92aaf2a8927f1c270c55a33eb52edb38a57c",
"functions_h.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';