var class_emb_sys_lib_1_1_hw_1_1_bitmap_1_1_header =
[
    [ "width", "class_emb_sys_lib_1_1_hw_1_1_bitmap_1_1_header.html#a1fd31a71d8ffffeeacaa6eef4782ee24", null ],
    [ "height", "class_emb_sys_lib_1_1_hw_1_1_bitmap_1_1_header.html#a919b3b1495d055253ab29ef130f6d9cf", null ],
    [ "bitsPerPixel", "class_emb_sys_lib_1_1_hw_1_1_bitmap_1_1_header.html#a589dbb70ff92d3d6296f0822132a9ecc", null ]
];