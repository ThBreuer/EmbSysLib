var class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data =
[
    [ "Flags", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295f", [
      [ "NONE", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "PRESSED", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fa5ef9a100ac8b4b8d6dec477c377b7901", null ],
      [ "MOVE_X", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fa7a40fd5b5569160d38c2328bf2fb5ed4", null ],
      [ "MOVE_Y", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fa2759e3c2bb672243131899864a890d33", null ],
      [ "CTRL_DWN", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fa1134888ffeeb8c5c0c4fddb9a70678c6", null ],
      [ "CTRL_UP", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fa9e0d87c59dc87c2e8b55e59589161c71", null ]
    ] ],
    [ "posX", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#a8e1d300d2defb75ef72730849305ef4f", null ],
    [ "posY", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#a1613b0d2480cd512dd0f87fd40f91385", null ],
    [ "delta", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#a1dfcb70b9229f2da17dd5922b87ecf2c", null ],
    [ "flags", "class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa991e2b209ef26272bf4fd920777bcda", null ]
];