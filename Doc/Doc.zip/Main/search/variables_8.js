var searchData=
[
  ['lastid_0',['lastId',['../class_emb_sys_lib_1_1_hw_1_1_font_1_1_header.html#a93d852512e62f010c0eb5643e18e52e4',1,'EmbSysLib::Hw::Font::Header']]]
];
