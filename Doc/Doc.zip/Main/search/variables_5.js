var searchData=
[
  ['globalcode_0',['globalCode',['../class_emb_sys_lib_1_1_std_1_1_report.html#afb7995cfc4ef37410b1c024c6546d132',1,'EmbSysLib::Std::Report']]],
  ['globalmodule_1',['globalModule',['../class_emb_sys_lib_1_1_std_1_1_report.html#a798f36e6ace9f3dbe823d859e990bbc6',1,'EmbSysLib::Std::Report']]]
];
