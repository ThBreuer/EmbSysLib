var searchData=
[
  ['bitsperpixel_0',['bitsPerPixel',['../class_emb_sys_lib_1_1_hw_1_1_bitmap_1_1_header.html#a589dbb70ff92d3d6296f0822132a9ecc',1,'EmbSysLib::Hw::Bitmap::Header']]],
  ['byteperchar_1',['bytePerChar',['../class_emb_sys_lib_1_1_hw_1_1_font_1_1_header.html#a6496ecebc0f35080e1a60a1f0830cf5c',1,'EmbSysLib::Hw::Font::Header']]]
];
