var searchData=
[
  ['move_5fx_0',['MOVE_X',['../class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fa7a40fd5b5569160d38c2328bf2fb5ed4',1,'EmbSysLib::Dev::Pointer::Data']]],
  ['move_5fy_1',['MOVE_Y',['../class_emb_sys_lib_1_1_dev_1_1_pointer_1_1_data.html#aa705cf7e79a21c2352b00ffe20cd295fa2759e3c2bb672243131899864a890d33',1,'EmbSysLib::Dev::Pointer::Data']]]
];
