var searchData=
[
  ['year_0',['year',['../class_emb_sys_lib_1_1_hw_1_1_rtc_1_1_properties.html#a4a6fc53e8955a835b6ec3c37a45c0423',1,'EmbSysLib::Hw::Rtc::Properties']]]
];
