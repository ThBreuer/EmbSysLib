var class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o =
[
    [ "Status", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html#a67a0db04d321a74b7e7fcfd3f1a3f70b", [
      [ "STARTED", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html#a67a0db04d321a74b7e7fcfd3f1a3f70ba9671ef15a84681350d508f66e1fc1e27", null ],
      [ "STOPPED", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html#a67a0db04d321a74b7e7fcfd3f1a3f70ba948b2aee15f52b421fa4770c47bcfe8c", null ]
    ] ],
    [ "USBdeviceSimpleIO", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html#aac3d91fb33640db7afab8f68a99fda9d", null ],
    [ "transmit", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html#a0efd706c5824b9f6af3f705a117ff7c7", null ],
    [ "receive", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html#afcbf255814daa1be43d76abab67c887d", null ],
    [ "status", "class_emb_sys_lib_1_1_mod_1_1_u_s_bdevice_simple_i_o.html#a22f6484d039401b18760698003788909", null ]
];