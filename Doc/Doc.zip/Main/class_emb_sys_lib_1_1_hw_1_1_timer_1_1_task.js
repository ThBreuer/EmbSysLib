var class_emb_sys_lib_1_1_hw_1_1_timer_1_1_task =
[
    [ "update", "class_emb_sys_lib_1_1_hw_1_1_timer_1_1_task.html#ab5a3cb47c0d5985f0a73944936a691fa", null ],
    [ "getNext", "class_emb_sys_lib_1_1_hw_1_1_timer_1_1_task.html#a72e63f7e2a17f55e128a3dd069e22e39", null ]
];