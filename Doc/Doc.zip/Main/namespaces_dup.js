var namespaces_dup =
[
    [ "EmbSysLib", "namespace_emb_sys_lib.html", "namespace_emb_sys_lib" ]
];