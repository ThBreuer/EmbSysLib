var class_emb_sys_lib_1_1_hw_1_1_i2_cslave_1_1_data_handler =
[
    [ "receive", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave_1_1_data_handler.html#ad1ae71c97ff800fc54f0e31e279a50b2", null ],
    [ "transmit", "class_emb_sys_lib_1_1_hw_1_1_i2_cslave_1_1_data_handler.html#a7177ace2df487f6fd1c94ff4bba5b1e8", null ]
];