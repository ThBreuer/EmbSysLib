var class_emb_sys_lib_1_1_hw_1_1_s_p_islave =
[
    [ "DataHandler", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave_1_1_data_handler.html", "class_emb_sys_lib_1_1_hw_1_1_s_p_islave_1_1_data_handler" ]
];